#!/bin/bash
# Установка приёма заявок Silver Song на Ubuntu. Запускать от root:
#   sudo bash INSTALL.sh
set -euo pipefail

APP=/opt/silversong
SRC="$(cd "$(dirname "$0")" && pwd)"

echo "== 1. Пакеты"
apt-get update -y
apt-get install -y python3 python3-pip git curl unzip ca-certificates snapd ufw

echo "== 2. Chromium (snap)"
if ! command -v chromium >/dev/null; then
  snap install chromium || apt-get install -y chromium-browser || true
fi
ln -sf /snap/bin/chromium /usr/bin/chromium 2>/dev/null || true

echo "== 3. Запрет сна"
systemctl mask sleep.target suspend.target hibernate.target hybrid-sleep.target || true

echo "== 4. Пользователь и папка"
id silversong >/dev/null 2>&1 || useradd -m -s /bin/bash silversong
mkdir -p "$APP"
if [ "$SRC" != "$APP" ]; then
  cp -a "$SRC"/. "$APP"/
fi
mkdir -p "$APP/.chrome-profile" "$APP/otdel-prodazh/runtime/logs"
chown -R silversong:silversong "$APP"

echo "== 5. Службы"
cp "$APP"/systemd/*.service "$APP"/systemd/*.timer /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now chrome-cdp.service
systemctl enable --now silversong-health.service
systemctl enable --now silversong-poll.timer

echo "== 6. Порты"
# Ollama закрываем от интернета, оставляем локально
ufw allow 22/tcp || true
ufw allow 8790/tcp || true
ufw deny 11434/tcp || true
ufw --force enable || true

echo "== 7. Проверка"
sleep 3
systemctl --no-pager --lines=3 status silversong-health.service || true
curl -s http://127.0.0.1:8790/health || echo "сторож ещё не отвечает"
echo
echo "Готово. Дальше: положить токен MAX в $APP/otdel-prodazh/runtime/ и cookies в профиль Chrome."
