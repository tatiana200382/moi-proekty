ЗАДАНИЕ: круглосуточный приём заявок Silver Song
============================================================
Сервер: ai.m-tik.com (Ubuntu 26.04). Доступ по SSH нам не нужен —
всё делаете вы, по этой инструкции. Мы потом проверим снаружи.

ЧТО ДЕЛАЕМ
Заявки из Авито и ВКонтакте должны попадать в чат MAX, даже когда
компьютер владельца выключен. Для этого на сервере каждые 15 минут
запускается скрипт: читает новые сообщения в кабинетах и отправляет
карточки в MAX. Ничего не публикуется, только чтение и уведомления.

ШАГ 1. Скопировать архив на сервер и распаковать
  scp silversong-server.tar.gz root@ai.m-tik.com:/root/
  ssh root@ai.m-tik.com
  tar -xzf /root/silversong-server.tar.gz -C /root/
  cd /root/silversong

ШАГ 2. Запустить установку
  sudo bash INSTALL.sh

Скрипт сам:
  - поставит python3, chromium (snap), ufw;
  - создаст пользователя silversong и папку /opt/silversong;
  - запретит сон сервера;
  - включит три службы: чтение Авито/ВК (каждые 15 минут),
    сторож /health на порту 8790, браузер Chrome с отладочным портом;
  - закроет порт 11434 от интернета (сейчас Ollama открыта всем).

ШАГ 3. Положить файлы доступа
  3.1 Токен бота MAX:
      файл token  ->  /opt/silversong/otdel-prodazh/runtime/max-bot/token
      (мы пришлём отдельным сообщением, это секрет)

  3.2 Сертификат MAX:
      файл max-ca.pem  ->  /opt/silversong/max-ca.pem

  3.3 Cookies Авито и ВК:
      файл cookies.json  ->  /opt/silversong/secrets/cookies.json
      Вход в кабинеты выполним вместе: на 10 минут откройте порт 9224
      для нашего IP, мы загрузим сессию, затем порт закроете.
      Правило файрвола, пример:
         ufw allow from 146.120.73.71 to any port 9224 proto tcp

  После файлов:
      chown -R silversong:silversong /opt/silversong
      systemctl restart chrome-cdp silversong-health
      systemctl start silversong-poll.service

ШАГ 4. Проверить и прислать нам
  systemctl status silversong-poll.timer --no-pager | head -5
  systemctl status silversong-health.service --no-pager | head -5
  curl -s http://127.0.0.1:8790/health
  tail -30 /opt/silversong/otdel-prodazh/runtime/logs/run.log

Пришлите нам вывод этих команд и ответьте на три вопроса:
  1. Это физический сервер или VPS?
  2. Есть ли ИБП (бесперебойник)?
  3. IP-адрес сервера (внешний), чтобы мы проверили сторож.

ЧТО МЫ ПРОВЕРИМ СНАРУЖИ
  - http://<IP>:8790/health  -> должно быть {"ok": true}
  - затем попросим написать тестовое сообщение в Авито
    и убедимся, что карточка пришла в чат MAX.

ЧЕГО НЕ ДЕЛАЕМ
  - не даём SSH-доступ посторонним;
  - не открываем наружу порт 11434 (модели) и 9224 (отладка);
  - не публикуем ничего в Авито: только чтение сообщений.

ЕСЛИ ЧТО-ТО НЕ СТАВИТСЯ
  Пришлите вывод:
    sudo bash -x INSTALL.sh 2>&1 | tail -60
